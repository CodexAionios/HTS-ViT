# Installation Guide

## Prerequisites

- Python 3.8 or higher
- PyTorch
- CUDA (for GPU support)

## Setup Instructions

1. **Clone the repository**:
   ```bash
   git clone https://github.com/CodexAionios/HTS-ViT.git
   cd HTS-ViT
   ```

2. **Create a virtual environment**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Run tests to ensure everything is set up correctly**:
   ```bash
   pytest
   ```

5. **Explore the examples**:
   Navigate to the `examples` directory and run the notebooks to see HTS-ViT in action.

## Troubleshooting

If you encounter any issues, please check our [FAQ](docs/FAQ.md) or open an issue on GitHub.