---
name: Setup Initial Repository Structure
about: Create the initial repository structure for HTS-ViT
title: Setup Initial Repository Structure
labels: documentation, setup, good-first-issue
assignees: ''

---

## Description

Create the initial repository structure for HTS-ViT, including key documentation files and folder organization.

## Tasks

- [ ] Create README.md
- [ ] Create CONTRIBUTING.md
- [ ] Create LICENSE file
- [ ] Setup docs folder with INSTALL.md and FAQ.md
- [ ] Create initial folder structure for src, examples, and tests