---
name: Write Unit Tests for Core Components
about: Write unit tests for the core components of HTS-ViT
title: Write Unit Tests for Core Components
labels: testing, good-first-issue
assignees: ''

---

## Description

Write unit tests for the core components of HTS-ViT to ensure correctness and stability of the implementation.

## Tasks

- [ ] Write tests for hypergraph-tensor representation
- [ ] Write tests for self-attention mechanism
- [ ] Ensure high test coverage
- [ ] Run tests and document results